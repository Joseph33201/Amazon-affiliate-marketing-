import React from 'react';
import Header from './components/Header';
import Timer from './components/Timer';
import Hero from './components/Hero';
import Features from './components/Features';
import HowItWorks from './components/HowItWorks';
import ProductShowcase from './components/ProductShowcase';
import Testimonials from './components/Testimonials';
import FAQ from './components/FAQ';
import CallToAction from './components/CallToAction';
import Footer from './components/Footer';
import RecentPurchaseNotification from './components/RecentPurchaseNotification';
export function App() {
  return <div className="bg-white w-full min-h-screen">
      <Header />
      <Timer />
      <Hero />
      <Features />
      <HowItWorks />
      <ProductShowcase />
      <Testimonials />
      <FAQ />
      <CallToAction />
      <Footer />
      <RecentPurchaseNotification />
    </div>;
}