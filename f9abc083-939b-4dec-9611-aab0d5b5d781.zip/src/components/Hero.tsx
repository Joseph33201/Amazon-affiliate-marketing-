import React from 'react';
const Hero = () => {
  return <section className="bg-gradient-to-b from-teal-50 to-white py-16 md:py-24">
      <div className="container mx-auto px-6 flex flex-col md:flex-row items-center">
        <div className="md:w-1/2 md:pr-10">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
            Discover Cleaner, Healthier Skin
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Clean Skin Club's premium towels are designed to give you the
            cleanest, healthiest skin possible. Say goodbye to bacteria and
            hello to a fresh face every day.
          </p>
          <a href="#buy-now" className="inline-block bg-teal-600 text-white px-8 py-3 rounded-md text-lg font-semibold hover:bg-teal-700 transition duration-300">
            Shop Now on Amazon
          </a>
        </div>
        <div className="md:w-1/2 mt-10 md:mt-0">
          <img src="https://i.postimg.cc/MGBPFSQn/109-1800x1800.png" alt="Clean Skin Club Towel" className="rounded-lg shadow-xl max-w-full mx-auto" />
        </div>
      </div>
    </section>;
};
export default Hero;