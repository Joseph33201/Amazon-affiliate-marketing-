import React from 'react';
import { ArrowRightIcon, CheckIcon, SparklesIcon, HeartIcon } from 'lucide-react';
const HowItWorks = () => {
  const steps = [{
    icon: <SparklesIcon className="h-8 w-8 text-teal-500" />,
    title: 'Unpack Your Fresh Towel',
    description: 'Each Clean Skin Club towel comes individually wrapped to ensure maximum cleanliness and hygiene.'
  }, {
    icon: <CheckIcon className="h-8 w-8 text-teal-500" />,
    title: 'Cleanse Your Face',
    description: 'Use your favorite cleanser to wash away dirt, oil, and makeup from your face.'
  }, {
    icon: <ArrowRightIcon className="h-8 w-8 text-teal-500" />,
    title: 'Gently Pat Dry',
    description: 'Use your Clean Skin Club towel to gently pat your skin dry - no rubbing required!'
  }, {
    icon: <HeartIcon className="h-8 w-8 text-teal-500" />,
    title: 'Enjoy Cleaner Skin',
    description: 'Experience the difference of truly clean skin without bacteria transfer from used towels.'
  }];
  return <section className="py-16 bg-teal-50">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-800 mb-4">
          How Clean Skin Club Works
        </h2>
        <p className="text-center text-gray-600 mb-12 max-w-3xl mx-auto">
          Our innovative single-use face towels are designed to give you the
          cleanest, healthiest skin possible. Follow these simple steps to
          transform your skincare routine.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((step, index) => <div key={index} className="bg-white p-6 rounded-lg shadow-md relative">
              <div className="absolute -top-4 -left-4 bg-teal-600 rounded-full w-10 h-10 flex items-center justify-center text-white font-bold">
                {index + 1}
              </div>
              <div className="flex justify-center mb-4">{step.icon}</div>
              <h3 className="text-xl font-semibold text-gray-800 text-center mb-3">
                {step.title}
              </h3>
              <p className="text-gray-600 text-center">{step.description}</p>
            </div>)}
        </div>
        <div className="mt-12 text-center">
          <p className="text-gray-700 font-medium mb-6">
            Say goodbye to bacteria-laden towels and hello to cleaner, clearer
            skin!
          </p>
          <a href="#buy-now" className="inline-block bg-teal-600 text-white px-6 py-3 rounded-md font-semibold hover:bg-teal-700 transition duration-300">
            Try Clean Skin Club Today
          </a>
        </div>
      </div>
    </section>;
};
export default HowItWorks;