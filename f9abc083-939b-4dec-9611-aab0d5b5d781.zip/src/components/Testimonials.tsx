import React from 'react';
import { StarIcon } from 'lucide-react';
const Testimonials = () => {
  const testimonials = [{
    name: 'Sarah L.',
    review: 'These towels completely changed my skincare routine! My acne has cleared up significantly since I stopped using regular towels.',
    rating: 5
  }, {
    name: 'Michael T.',
    review: "As someone with sensitive skin, I was skeptical, but these towels are incredibly soft and don't irritate my skin at all.",
    rating: 5
  }, {
    name: 'Jessica K.',
    review: "I love that I can use a fresh towel every day. It's made such a difference in my skin's clarity and texture.",
    rating: 5
  }];
  return <section id="testimonials" className="py-16 bg-white">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-800 mb-4">
          What Our Customers Say
        </h2>
        <p className="text-center text-gray-600 mb-12 max-w-3xl mx-auto">
          Join thousands of satisfied customers who have transformed their
          skincare routine with Clean Skin Club.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => <div key={index} className="bg-gray-50 p-6 rounded-lg shadow-sm">
              <div className="flex mb-4">
                {[...Array(testimonial.rating)].map((_, i) => <StarIcon key={i} className="h-5 w-5 text-yellow-400 fill-current" />)}
              </div>
              <p className="text-gray-600 mb-4 italic">
                "{testimonial.review}"
              </p>
              <p className="text-gray-800 font-semibold">{testimonial.name}</p>
            </div>)}
        </div>
      </div>
    </section>;
};
export default Testimonials;