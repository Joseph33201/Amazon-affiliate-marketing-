import React from 'react';
const CallToAction = () => {
  return <section id="buy-now" className="py-16 bg-teal-600">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
          Ready for Cleaner, Healthier Skin?
        </h2>
        <p className="text-white text-lg mb-8 max-w-2xl mx-auto">
          Join thousands of satisfied customers who have transformed their
          skincare routine with Clean Skin Club towels.
        </p>
        <div className="bg-white p-6 rounded-lg shadow-xl max-w-xl mx-auto mb-8">
          <h3 className="text-teal-600 text-xl font-bold mb-3">
            LIMITED TIME OFFER
          </h3>
          <p className="text-gray-700 text-lg mb-4">
            Get 25% OFF your first order when you purchase today!
          </p>
          <p className="text-gray-600 mb-4">
            This special discount won't last long - order now before time runs
            out!
          </p>
        </div>
        <a href="https://amzn.to/4lnhnaL" target="_blank" rel="noopener noreferrer" className="inline-block bg-white text-teal-600 px-8 py-4 rounded-md text-lg font-semibold hover:bg-gray-100 transition duration-300 shadow-lg">
          Shop Now on Amazon
        </a>
        <p className="text-white text-sm mt-6 opacity-80">
          *Free shipping available on qualifying orders
        </p>
      </div>
    </section>;
};
export default CallToAction;