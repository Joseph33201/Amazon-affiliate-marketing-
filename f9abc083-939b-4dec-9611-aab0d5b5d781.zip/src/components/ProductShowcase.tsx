import React from 'react';
const ProductShowcase = () => {
  const products = [{
    image: 'https://i.postimg.cc/MGBPFSQn/109-1800x1800.png',
    alt: 'Clean Skin Club Towel Package',
    title: 'Clean Skin Club Face Towels',
    description: 'Our signature product - ultra-soft, single-use towels designed for optimal facial cleansing.'
  }, {
    image: 'https://i.postimg.cc/MHqFBFXv/1-C07-DDC4-D5-E9-4-BA7-97-CC-AB31-C5-AE115-A-2048x.jpg',
    alt: 'Clean Skin Club Towel Usage',
    title: 'Perfect Daily Use',
    description: 'Experience the luxury of a fresh, clean towel with every facial cleanse.'
  }, {
    image: 'https://i.postimg.cc/mkLmk169/1-db48ca5b-a840-4621-aac4-3e6385ce08c8-1800x1800.png',
    alt: 'Clean Skin Club Towel',
    title: 'Premium Bamboo Fibers',
    description: 'Made from sustainable bamboo fibers that are gentle on your skin and the environment.'
  }, {
    image: 'https://i.postimg.cc/85VK80Rt/36-12895827-ebb9-47a8-9a87-5b1ad1f5688c-1800x1800.png',
    alt: 'Clean Skin Club Product',
    title: 'Multi-Pack Options',
    description: 'Available in packs of 50, 100, or 200 towels to suit your needs and budget.'
  }, {
    image: 'https://i.postimg.cc/90hvpfgX/61fa-C6wk-Jn-L-UF1000-1000-QL80.jpg',
    alt: 'Clean Skin Club Product Box',
    title: 'Convenient Packaging',
    description: 'Our sleek, compact packaging makes storage easy and keeps your towels clean until use.'
  }, {
    image: 'https://i.postimg.cc/rwP3HjZP/71-LG1yme-Ng-L-UF350-350-QL80.jpg',
    alt: 'Clean Skin Club Towel Close-up',
    title: 'Ultra-Soft Texture',
    description: 'Each towel features our signature ultra-soft texture that feels luxurious on your skin.'
  }];
  return <section id="products" className="py-16 bg-gray-50">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-800 mb-4">
          Our Premium Products
        </h2>
        <p className="text-center text-gray-600 mb-12 max-w-3xl mx-auto">
          Experience the luxury of Clean Skin Club's premium towels designed for
          optimal skincare results.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product, index) => <div key={index} className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition duration-300">
              <div className="h-64 overflow-hidden">
                <img src={product.image} alt={product.alt} className="w-full h-full object-cover transform hover:scale-105 transition duration-500" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-2">
                  {product.title}
                </h3>
                <p className="text-gray-600">{product.description}</p>
              </div>
            </div>)}
        </div>
        <div className="mt-12 bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-2xl font-semibold text-gray-800 mb-4 text-center">
            Why Choose Single-Use Towels?
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="text-lg font-medium text-teal-600 mb-2">
                The Problem with Regular Towels:
              </h4>
              <ul className="list-disc pl-5 text-gray-700 space-y-2">
                <li>Harbor bacteria even after washing</li>
                <li>Transfer bacteria back to your skin with each use</li>
                <li>Contribute to breakouts and skin irritation</li>
                <li>Become rough and abrasive over time</li>
                <li>Require frequent washing and maintenance</li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-medium text-teal-600 mb-2">
                The Clean Skin Club Solution:
              </h4>
              <ul className="list-disc pl-5 text-gray-700 space-y-2">
                <li>Fresh, clean towel with every use</li>
                <li>Zero bacterial transfer to your skin</li>
                <li>Helps prevent breakouts and irritation</li>
                <li>Always soft and gentle on your skin</li>
                <li>No washing required - convenient and time-saving</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>;
};
export default ProductShowcase;