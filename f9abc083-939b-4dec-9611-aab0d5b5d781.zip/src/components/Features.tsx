import React from 'react';
import { CheckCircleIcon } from 'lucide-react';
const Features = () => {
  const benefits = [{
    title: 'Ultra-Soft Material',
    description: 'Made from premium materials for a gentle touch on your sensitive skin.'
  }, {
    title: 'Antibacterial Protection',
    description: 'Designed to prevent bacterial growth, keeping your skin clean and healthy.'
  }, {
    title: 'Single-Use Design',
    description: 'Fresh towel every time means no more reusing bacteria-laden cloths.'
  }, {
    title: 'Eco-Friendly',
    description: 'Sustainably made with environmentally conscious materials.'
  }, {
    title: 'Perfect for All Skin Types',
    description: 'Gentle enough for sensitive skin, effective for all skin concerns.'
  }, {
    title: 'Travel-Friendly',
    description: 'Compact design makes it perfect for on-the-go skincare.'
  }];
  return <section id="features" className="py-16 bg-white">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-800 mb-12">
          Why Choose Clean Skin Club?
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => <div key={index} className="bg-gray-50 p-6 rounded-lg shadow-sm hover:shadow-md transition duration-300">
              <div className="flex items-start mb-4">
                <CheckCircleIcon className="h-6 w-6 text-teal-600 mr-2 flex-shrink-0" />
                <h3 className="text-xl font-semibold text-gray-800">
                  {benefit.title}
                </h3>
              </div>
              <p className="text-gray-600">{benefit.description}</p>
            </div>)}
        </div>
      </div>
    </section>;
};
export default Features;