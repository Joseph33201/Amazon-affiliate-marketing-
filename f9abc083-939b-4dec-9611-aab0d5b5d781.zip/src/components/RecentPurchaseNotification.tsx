import React, { useEffect, useState } from 'react';
import { ShoppingBagIcon } from 'lucide-react';
const RecentPurchaseNotification = () => {
  const [visible, setVisible] = useState(false);
  const [currentNotification, setCurrentNotification] = useState(0);
  // Mock data of recent purchases
  const recentPurchases = [{
    name: 'Sarah',
    location: 'New York',
    time: '2 minutes ago'
  }, {
    name: 'Michael',
    location: 'Los Angeles',
    time: '5 minutes ago'
  }, {
    name: 'Emily',
    location: 'Chicago',
    time: '7 minutes ago'
  }, {
    name: 'David',
    location: 'Austin',
    time: '12 minutes ago'
  }, {
    name: 'Jessica',
    location: 'Miami',
    time: '15 minutes ago'
  }, {
    name: 'Robert',
    location: 'Seattle',
    time: '18 minutes ago'
  }, {
    name: 'Amanda',
    location: 'Boston',
    time: '20 minutes ago'
  }, {
    name: 'Thomas',
    location: 'Denver',
    time: '25 minutes ago'
  }];
  useEffect(() => {
    // Function to show notification
    const showNotification = () => {
      setVisible(true);
      // Hide after 4 seconds
      setTimeout(() => {
        setVisible(false);
        // Set next notification
        setTimeout(() => {
          setCurrentNotification(prev => prev === recentPurchases.length - 1 ? 0 : prev + 1);
        }, 500);
      }, 4000);
    };
    // Initial delay before first notification
    const initialTimeout = setTimeout(() => {
      showNotification();
      // Set interval for recurring notifications
      const interval = setInterval(showNotification, 15000);
      // Clean up interval
      return () => clearInterval(interval);
    }, 5000);
    // Clean up initial timeout
    return () => clearTimeout(initialTimeout);
  }, [recentPurchases.length]);
  const purchase = recentPurchases[currentNotification];
  return <div className={`fixed bottom-8 left-0 z-50 transform ${visible ? 'translate-x-0' : '-translate-x-full'} transition-transform duration-500 ease-in-out`}>
      <div className="bg-white rounded-r-lg shadow-lg p-4 flex items-center max-w-xs border-l-4 border-teal-600">
        <div className="bg-teal-100 rounded-full p-2 mr-3">
          <ShoppingBagIcon className="h-5 w-5 text-teal-600" />
        </div>
        <div>
          <p className="text-sm font-medium text-gray-800">
            {purchase.name} from {purchase.location}
          </p>
          <p className="text-xs text-gray-500">
            purchased Clean Skin Club towels {purchase.time}
          </p>
        </div>
      </div>
    </div>;
};
export default RecentPurchaseNotification;