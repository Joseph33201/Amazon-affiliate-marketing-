import React, { useState } from 'react';
import { ChevronDownIcon, ChevronUpIcon } from 'lucide-react';
const FAQ = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  const faqs = [{
    question: 'How many towels come in a package?',
    answer: 'Clean Skin Club towels come in packages of 50, 100, or 200 towels, depending on which option you choose. This gives you a fresh, clean towel for each day.'
  }, {
    question: 'Are Clean Skin Club towels eco-friendly?',
    answer: "Yes! Our towels are made from sustainable bamboo fibers that are biodegradable and environmentally friendly. We're committed to providing products that are good for your skin and the planet."
  }, {
    question: 'How do Clean Skin Club towels help with acne?',
    answer: 'Regular towels harbor bacteria even after washing, which can transfer back to your skin and cause breakouts. Our single-use towels eliminate this problem by providing a fresh, clean towel for every use, reducing bacterial transfer and helping to clear acne.'
  }, {
    question: 'Are these towels suitable for sensitive skin?',
    answer: "Absolutely! Clean Skin Club towels are ultra-soft and gentle, making them perfect for sensitive skin. They're free from harsh chemicals and irritants that can cause reactions."
  }, {
    question: 'How big are the towels?',
    answer: "Each towel measures approximately 8 x 10 inches, providing ample coverage for your face and neck. They're perfectly sized for facial cleansing and drying."
  }, {
    question: 'Can I use these towels for removing makeup?',
    answer: "While Clean Skin Club towels can help remove light makeup residue after cleansing, they're primarily designed for drying your face after washing. For best results, we recommend removing makeup with a dedicated makeup remover before cleansing."
  }];
  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };
  return <section id="faq" className="py-16 bg-white">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-800 mb-4">
          Frequently Asked Questions
        </h2>
        <p className="text-center text-gray-600 mb-12 max-w-3xl mx-auto">
          Everything you need to know about Clean Skin Club towels
        </p>
        <div className="max-w-3xl mx-auto">
          {faqs.map((faq, index) => <div key={index} className="border-b border-gray-200 py-4">
              <button className="flex justify-between items-center w-full text-left font-medium text-gray-800 hover:text-teal-600 focus:outline-none transition duration-300" onClick={() => toggleFAQ(index)}>
                <span className="text-lg">{faq.question}</span>
                {openIndex === index ? <ChevronUpIcon className="h-5 w-5 text-teal-600" /> : <ChevronDownIcon className="h-5 w-5 text-gray-600" />}
              </button>
              {openIndex === index && <div className="mt-2 text-gray-600 pl-4 border-l-2 border-teal-200">
                  <p>{faq.answer}</p>
                </div>}
            </div>)}
        </div>
        <div className="text-center mt-12">
          <p className="text-gray-700 mb-4">
            Still have questions? We're here to help!
          </p>
          <a href="#buy-now" className="inline-block bg-teal-600 text-white px-6 py-2 rounded-md font-medium hover:bg-teal-700 transition duration-300">
            Get Your Clean Skin Club Towels Now
          </a>
        </div>
      </div>
    </section>;
};
export default FAQ;