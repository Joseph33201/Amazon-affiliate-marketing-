import React from 'react';
const Footer = () => {
  return <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-6 md:mb-0">
            <div className="text-xl font-bold text-teal-400 mb-2">
              Clean Skin Club
            </div>
            <p className="text-gray-400">
              Premium skincare products for healthier skin.
            </p>
          </div>
          <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-8">
            <a href="#features" className="text-gray-400 hover:text-teal-400">
              Benefits
            </a>
            <a href="#products" className="text-gray-400 hover:text-teal-400">
              Products
            </a>
            <a href="#testimonials" className="text-gray-400 hover:text-teal-400">
              Reviews
            </a>
            <a href="#faq" className="text-gray-400 hover:text-teal-400">
              FAQ
            </a>
            <a href="https://amzn.to/4lnhnaL" target="_blank" rel="noopener noreferrer" className="text-teal-400 hover:text-teal-300 font-medium">
              Buy Now
            </a>
          </div>
        </div>
        <div className="mt-10 text-center">
          <a href="https://amzn.to/4lnhnaL" target="_blank" rel="noopener noreferrer" className="inline-block bg-teal-600 text-white px-6 py-2 rounded-md hover:bg-teal-700 transition duration-300 mb-4">
            Shop on Amazon
          </a>
          <p className="text-gray-400 text-sm">
            Use our affiliate link to support this site
          </p>
        </div>
        <div className="border-t border-gray-800 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">
            © {new Date().getFullYear()} Clean Skin Club. All rights reserved.
          </p>
          <p className="text-gray-400 text-sm mt-4 md:mt-0">
            This site contains affiliate links to{' '}
            <a href="https://amzn.to/4lnhnaL" className="text-teal-400 hover:underline">
              Amazon
            </a>
            . We may earn a commission on qualifying purchases.
          </p>
        </div>
      </div>
    </footer>;
};
export default Footer;