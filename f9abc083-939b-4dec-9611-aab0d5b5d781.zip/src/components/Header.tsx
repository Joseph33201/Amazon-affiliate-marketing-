import React from 'react';
const Header = () => {
  return <header className="bg-white py-4 px-6 shadow-sm sticky top-0 z-50">
      <div className="container mx-auto flex justify-between items-center">
        <div className="text-xl font-bold text-teal-600">Clean Skin Club</div>
        <nav className="hidden md:block">
          <ul className="flex space-x-8">
            <li>
              <a href="#features" className="text-gray-600 hover:text-teal-600">
                Benefits
              </a>
            </li>
            <li>
              <a href="#products" className="text-gray-600 hover:text-teal-600">
                Products
              </a>
            </li>
            <li>
              <a href="#testimonials" className="text-gray-600 hover:text-teal-600">
                Reviews
              </a>
            </li>
          </ul>
        </nav>
        <a href="#buy-now" className="bg-teal-600 text-white px-4 py-2 rounded-md hover:bg-teal-700 transition duration-300">
          Buy Now
        </a>
      </div>
    </header>;
};
export default Header;