import React, { useEffect, useState } from 'react';
const Timer = () => {
  const [minutes, setMinutes] = useState(10);
  const [seconds, setSeconds] = useState(0);
  useEffect(() => {
    const interval = setInterval(() => {
      if (seconds > 0) {
        setSeconds(seconds - 1);
      } else if (minutes > 0) {
        setMinutes(minutes - 1);
        setSeconds(59);
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [minutes, seconds]);
  return <div className="bg-red-600 text-white py-2 sticky top-16 z-40 w-full">
      <div className="container mx-auto px-6 flex justify-between items-center">
        <p className="font-medium text-sm md:text-base">
          ⏱️ Limited Time Offer: Get 25% OFF Today!
        </p>
        <div className="font-bold text-sm md:text-base">
          {minutes.toString().padStart(2, '0')}:
          {seconds.toString().padStart(2, '0')} Remaining
        </div>
      </div>
    </div>;
};
export default Timer;